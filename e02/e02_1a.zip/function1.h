// function1.h for the example e02_1a.zip
// Header file (decleration) of the function1
// function1 increments the input parameter by 0.1
double function1(double);   // Decleration